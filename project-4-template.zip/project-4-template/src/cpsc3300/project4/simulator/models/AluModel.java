package cpsc3300.project4.simulator.models;

import cpsc3300.project4.simulator.Instruction;

public class AluModel {

	private boolean zeroFlag = false;
	private int result;

	public AluModel() {
		result = 0;
	}
	public int calculate(int data1, int data2, int operation) {
		// TODO: Return the result of ALU operation based on operation
		switch(operation) {
			// add
			case 2:
				result = data1 + data2;
				if(result == 0) zeroFlag = true;
				return data1 + data2;
			// subtract
			case 6:
				result = data1 - data2;
				return data1 - data2;
			// and
			case 0:
				result = data1 & data2;
				return data1 & data2;
			// or
			case 1:
				result = data1 | data2;
				return data1 | data2;
			default:
				return 0;
		}
	}

	public static byte getOperation(byte funct, int AluOp) {
		// TODO: Return ALU operation based on function and OpCode
		// for LW and SW
		if(AluOp == 0) {
			return (byte)2;
		}

		// for beq
		else if(AluOp == 1) {
			return (byte)6;
		}

		// for r-type instructions
		else if(AluOp == 10) {
			switch(funct) {
				// add
				case (byte)32:
					return (byte)2;
				// 	sub
				case (byte)34:
					return (byte)6;
				// and
				case (byte)36:
					return (byte)0;
				// or
				case (byte)37:
					return (byte)1;
				default:
					return -1;
			}
		}
		return -1;
	}

	public static byte getOperation(Instruction instr) {
		return getOperation(instr.getFunct(), instr.getAluOp());
	}

	public boolean isZeroFlag() {
		return zeroFlag;
	}

	public int getResult(){
		return result;
	}
}
