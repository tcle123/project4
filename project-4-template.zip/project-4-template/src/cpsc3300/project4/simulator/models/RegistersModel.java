package cpsc3300.project4.simulator.models;

public class RegistersModel {
	private int[] registers; // TODO: Identify number of registers to support
	public static final String[] registerNames = new String[32]; // TODO: Identify register names in order

	public RegistersModel() {
		// there are 32 registers in MIPS
		registers = new int[32];
		// giving all of the registers names
		// goes from reg0 to reg31
		for(int i = 0; i < 32; i++) {
			String regVal = String.valueOf(i);
			String regName = "reg" + regVal;
			// store the register name created above in the String array
			registerNames[i] = regName;
		}
	}

	public int readRegister(byte regAddr) {
		// TODO: return value in register given by index
		return registers[Byte.toUnsignedInt(regAddr)];
	}

	public void writeRegister(byte regAddr, int word) {
		// TODO: store value word in register given by index
		registers[Byte.toUnsignedInt(regAddr)] = word;
	}
}
